import React from 'react'
import ComB from './ComB'

const ComA = () => {
  return (
    <div>
       <h1 className="Com">Component A.</h1>
       <ComB/>
    </div>
  )
}

export default ComA
