import React from 'react'
import ComC from './ComC'

const ComB = () => {
  return (
    <div>
         <h1 className='Com'>Component B</h1>
         <ComC/>
    </div>
  )
}

export default ComB
