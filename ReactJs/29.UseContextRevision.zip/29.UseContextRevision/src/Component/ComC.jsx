import React from 'react'

const ComC = () => {
  return (
    <div>
        <h1 className='Com'>Component C</h1>
    </div>
  )
}

export default ComC
